/* mobile-ui.js (clean: mobile-only + safe reset + aria focus fix) */

(() => {
  const dd = document.getElementById("mobile-view-dd");
  const btn = document.getElementById("mobile-view-btn");
  const menu = document.getElementById("mobile-view-menu");

  const left = document.querySelector(".left-column");
  const odds = document.getElementById("odds-intelligence-center");
  const right = document.querySelector("aside.right-column");

  // elements must exist
  if (!dd || !btn || !menu) return;

  // ✅ helper: detect mobile
  const isMobile = () => window.matchMedia("(max-width: 900px)").matches;

  // ✅ helper: clear inline display so desktop CSS can take over
  function resetDesktopPanels() {
    document.body.classList.remove("mobile-view-left", "mobile-view-odds", "mobile-view-right");

    if (left) left.style.display = "";
    if (odds) odds.style.display = "";
    if (right) right.style.display = "";
  }

  function hideMenu() {
    // ✅ Fix: do not hide a container while a focused element lives inside it
    const active = document.activeElement;
    if (active && menu.contains(active)) active.blur();

    menu.classList.add("hidden");
    menu.setAttribute("aria-hidden", "true");
  }

  function showMenu() {
    menu.classList.remove("hidden");
    menu.setAttribute("aria-hidden", "false");
  }

  function setLabel(text) {
    const labelEl =
      document.getElementById("mobile-view-label") ||
      btn.querySelector(".mobile-view-label");

    if (labelEl) labelEl.textContent = text;
  }

  function setView(view) {
    // ✅ NEVER apply mobile switching in desktop
    if (!isMobile()) {
      resetDesktopPanels();
      hideMenu();
      return;
    }

    document.body.classList.remove("mobile-view-left", "mobile-view-odds", "mobile-view-right");

    // hide all (mobile only)
    if (left) left.style.display = "none";
    if (odds) odds.style.display = "none";
    if (right) right.style.display = "none";

    if (view === "left") {
      document.body.classList.add("mobile-view-left");
      if (left) left.style.display = "block";
      setLabel("LEFT");
    } else if (view === "odds") {
      document.body.classList.add("mobile-view-odds");
      if (odds) odds.style.display = "block";
      setLabel("ODDS");
    } else if (view === "right") {
      document.body.classList.add("mobile-view-right");
      if (right) right.style.display = "block";
      setLabel("RIGHT");
    } else {
      // fallback
      document.body.classList.add("mobile-view-left");
      if (left) left.style.display = "block";
      setLabel("LEFT");
    }

    hideMenu();
  }

  // ✅ public API used by matches-panel.js (keep it)
  window.AIML_MOBILE_SET_VIEW = setView;

  btn.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();

    // only functional on mobile
    if (!isMobile()) return;

    const isHidden = menu.classList.contains("hidden");
    if (isHidden) showMenu();
    else hideMenu();
  });

  menu.addEventListener("click", (e) => {
    const item = e.target.closest(".mobile-view-item");
    if (!item) return;

    const v = item.getAttribute("data-view");
    if (!v) return;

    setView(v);
  });

  document.addEventListener("click", (e) => {
    if (menu.classList.contains("hidden")) return;
    if (dd.contains(e.target)) return;
    hideMenu();
  });

  // ✅ critical: when resizing back to desktop, remove inline display locks
  window.addEventListener("resize", () => {
    if (!isMobile()) resetDesktopPanels();
  });

  // default view
  if (isMobile()) setView("left");
  else resetDesktopPanels();
})();
